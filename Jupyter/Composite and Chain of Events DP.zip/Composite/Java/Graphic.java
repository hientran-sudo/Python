/** "Component" */
interface Graphic {
 
    //Prints the graphic.
    public void print();
}